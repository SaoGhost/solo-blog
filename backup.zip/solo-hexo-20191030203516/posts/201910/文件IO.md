title: 文件IO
date: '2019-10-15 09:18:37'
updated: '2019-10-30 16:48:01'
tags: [Linux]
permalink: /articles/2019/10/15/1571102317255.html
---
![](https://img.hacpai.com/bing/20190711.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 
## 文件IO
--------

我们会介绍一些我们常见的文件IO；这些函数都是系统调用API

在我们普通文件进行IO操作的时候，需要先调用open() 获得一个 文件描述符，随后对read() 和 write() 进行操作，然后使用close()释放文件描述符及其相关的资源;   
所有类型的文件和设备驱动都实现了相同的I/O接口，这保证了IO操作系统的通用性，同时也意味着无需针对特定文件类型编写代码的情况下，程序通常能操作所有类型的文件；   
对于已经打开的文件。内核会维护一个文件偏移量，这决定了下一次或者写操作的起始位置，读和写操作会隐式的改变偏移量，而lseek会显式的改变偏移量；

------

### 一些常见文件 I/O 函数介绍
---
#### 1.open

打开一个文件

```
#include <fcntl.h>
int open (const char *__file, int __oflag, ...)
```

* **__file：** 要打开的文件
* **__oflag：** 文件访问模式
* **返回值：**  成功返回文件描述符，失败返回-1

##### 常用的文件访问模式标识

|访问模式|描述|
|---|---|
|O_RDONLY|以只读打开文件|
|O_WRONLY|以只写打开文件|
|O_RDWR|以读写模式打开文件|
|---|---|
|O_CLOEXEC|设置 close on exec 标识|
|O_CREAT|若文件不存在，就创建|
|O_DIRECT|无缓冲的输入输出|
|O_DIRECTORY|若文件不是目录，则失败|
|O_EXCL|结合 O_CREAT 参数使用，专门用啦创建文件|
|O_LARGEFILE|在 32 位系统中使用此标识打开大文件|
|IO_NOATIME|调用 read 时，不修改文件最近访问时间|
|O_NOCTTY|不要让文件成为控制终端|
|O_NOFOLLOW|对符号链接不允许解引用|
|O_TRUNC|阶段已有文件，使其长度为 0|
|----|----|
O_APPEND|总在文件尾部追加数据|
|O_ASYNC|当 I/O 操作可行时，产生信号通知进程|
|O_DSYNC|提供 IO 数据完整性|
|O_NOBLOCK|以非阻塞方式打开|
|O_SYNC|以同步方式打开|


---
#### 2.read

读取文件内容

```
#include <unistd.h>
ssize_t read (int __fd, void *__buf, size_t __nbytes)
```
* **_fd：** 从文件描述符指定的文件中读取文件;
* **nbytes：** 是最多能读取的大小；
* **buf ：** 是提供用来存放输入数据的内存缓冲区地址
如果调用成功，返回实际读取的字节数，如果遇到EOF 返回0；出现错误返回-1；

---
#### 3.write

数据写入文件

```
#include <unistd.h>
ssize_t write (int __fd, const void *__buf, size_t __n)
```
* **_fd：** 给文件描述符指定的文件中写入文件;
* **nbytes：** 是最多能写入的大小；
* **buf ：** 是提供用来存放写入数据的内存缓冲区地址
成功返回 实际写入的字节数；
对磁盘文件执行IO操作时，write 调用成功并不能保证

---
#### 4.close

close 调用关闭一个打开的文件描述符，并将其释放回调用进程；（当一个进程终止的时候，将自动关闭其打开的文件描述符）

```
#include <unistd.h>
int close (int __fd)
```


---
#### 5.lseek

对于每个打开的文件，系统内核会记录文件偏移量；文件偏移量是指下一个read 或者write 的文件起始位置

```
#include <unistd.h>
__off_t lseek (int __fd, __off_t __offset, int __whence)
```
* **__fd：** 指代已打开的文件描述符
* **offset：** 指定了一个以字节为单位的数值，规定为 有符号整形数
* **whence：** 表明了应该参考哪个基点来解释offset 参数

| 参数 | 解释 |
| --- | --- | --- |
| SEEK_SET |  将文件偏移量设置为从文件头部开始点开始的offset个字节 ，必须正数|  
| SEEK_CUR |  相对于当前的文件偏移量，将文件偏移量调整 offset 个字节，可为负数 |  
| SEEK_END| 将文件偏移量设置为文件尾部的offset个字节 ，可为负数|
调用成功会返回新的文件偏移量

---
#### 6.fcntl

这个系统调用，会对文件控制操作符执行一系列的控制操作；

```
#include <fcntl.h>
int fcntl (int __fd, int __cmd, ...);
```
* **__fd：**  一个打开的文件描述符
* ***cmd：**  
第三个参数 是可以省略的，按情况追加；


---
#### 7.pread()  和 pwrite()

系统调用pead 和pwrite 完成的工作和read 和write 相似，只是这两个函数会在offset 参数所指定的位置进行文件I/O操作，而不是文件的当前偏移量处，并且它们不会改变文件的当前偏移量；
```
#include <unistd.h>

ssize_t pread (int __fd, void *__buf, size_t __nbytes,__off_t __offset)

ssize_t pwrite (int __fd, const void *__buf, size_t __n, __off_t __offset)
```
这些系统调用在多线程应用下会有很大的用武之地，因为进程下的所有线程 都共享同以文件描述符，那么多个线程对同一个文件描述符进行IO操作的时候，就不会因为其他线程改变了文件偏移量而收到影响；但是你如果使用lseek  read 和write，就会引发竞争关系；

---
#### 8.readv()和 writev()

分散输入和集中输出

```
#include <sys/uio.h>

ssize_t readv (int __fd, const struct iovec *__iovec, int __count)

size_t writev (int __fd, const struct iovec *__iovec, int __count)
```


---
#### 9.truncate() 和 ftruncate()

截断文件

```
#include <unistd.h>

int truncate (const char *__file, __off_t __length)

int ftruncate (int __fd, __off_t __length)
```
若文件长度大于length，就丢弃超出部分，如果小于参数length，就在文件尾部添加一系列的空字节或是一个文件空洞；
两个函数的不同是，第一个 以路径名字来指定文件，并要求可访问该文件，且对文件有读写权限，如果文件名为符号链接，进行解引用；第二个函数需要以可写方式打开操作文件，获取文件描述符以指代该文件，该系统调用不会修改文件偏移量；
成功返回0，失败返回-1；

---
