title: Linux ： 信号相关的函数
date: '2019-10-10 18:10:37'
updated: '2019-10-11 10:04:21'
tags: [C, Linux, 操作系统]
permalink: /articles/2019/10/10/1570702237821.html
---
![](https://img.hacpai.com/bing/20181217.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

---
## 信号

---
### 信号是什么：

---
信号是事件发生时对进程的通知机制。有时也被称为软件中断，因为它和硬件中断的相似之处在于打断了程序执行的正确流程；比如一个进程正在运行，然后 fork 了一个子进程，子进程在执行完毕后，发送了一个信号。让父进程知道它终止了，然后父进程 就回来处理子进程终止的一些事情；

---
信号分为两大类：

* 第一组用于内核向进程通知事件，构成传统或者标准信号；
* 第二组是由实时信号产生的；

---
信号因为某些时间而产生；信号产生以后，会被传递给某个进程，而进程来采取相应的措施来相应信号；在信号产生和到达期间，信号处于等待(pending)状态；

---
#### 信号类型和默认行为

* **term ：** 表示信号终止进程
* **core  ：** 表示进程产生核心转储文件并退出
* **ignore：** 表示忽略该信号
* **stop**：表示信号停止了进程
* **cont：** 表示信号恢复了一个已停止的进程

| 名称 | 信号值 | 描述 | 默认 |
| --- | --- | --- |
| SIGABRT |  6 |  中止进程 |  core |
| SIGALRM |  14 |  定时定时器过期 |  term |
| SIGBUS |  7 ，10 |  内存访问错误 |  core |
|  SIGHLD |  17,20,18 |  终止或者停止子进程 |  ignore |
|  SIGCONT |  18,19,25,26 |  若停止则继续 |  cont |
| SIGEMT |  7 |  硬件错误 |  term |
|  SIGFPE |  8 |  算数异常 |  core |
| SIGHUP |  1 |  挂起 |  term |
| SIGILL |  4 |  非法指令 |  core |
| SIGINT |  2 |  终端中断 |  term |
| SIGIO |  29,23,22 |  I/O 时可能产生 |  term |
| SIGPOLL |  18,19,25,26 |   |   |
| SIGKILL |  9 |  必杀（确保杀死） |  term |
|  SIGPIPE |  13 |  管道断开 |  term |
| SIGPROF |  27,29,21 |  性能分析定时器过期 |  term |
| SIGPWR |  30,29,19 |  电量将耗尽 |  term |
| SIGQUIT |  3 |  终端退出 |  core |
| SIGSEGV |  11 |  无效的内存引用 |  core |
| SIGSTKFLT |  16,undef，36 |  协处理器栈错误 |  term |
| SIGSTOP |  19,17,23,24 |  确保停止 |  stop |
| SIGSYS |  31,12, |  无效的系统调用 |  core |
| SIGTERM |  15 |  终止进程 |  term |
| SIGTRAR |  5 |  跟踪/断点陷阱 |  core |
| SIGTSTP |  20,18,24,25 |  终端停止 |  stop |
| SIGTTIN |  21,26,27 |  BG1 从终端读取 |  stop |
| SIGTTOU |  22,27，28 |  BG 向终端写 |  stop |
| SIGURG |  23,16,21,29 |  套接字上的紧急数据 |  ignore |
| SIGUSR1 |  10,30,16 |  用户自定义信号 1 |  term |
| SIGUSR2 |  12,31,17, |  用户自定义用户 2 |  term |
| SIGVTALRM |  26,28,20 |  虚拟定时器过期 |  term |
| SIGWINCH |  28,20,23 |  终端窗口尺寸发生变化 |  ignore |
| SIGXCPU |  24,30,33 |  突破对 CPU 时间的限制 |  core |
| SIGXFSZ |  25,31,34 |  突破对文件大小的限制 |  core |

---
## 信号处理

---
### 信号注册函数

##### signal()

```
#include <signal.h>
 __sighandler_t signal ( int __sig  __sighandler_t __handler)
```

* **__sighandler_t:** 是一个函数指针 void（* __sighandler_t）(int)
* **__sig:** 在信号处理程序中作为变量使用的信号码； 信號的處理功能被設置的號碼；用在 &lt;bits/signum.h&gt; 中的宏定义的参数，常用的 SIGCHLD，SIGINT，SIGALRM；
* **_handle：** 这是一个指向函数的指针；这里是可以由程序员定义的函数；

---
##### signaction()

```
int sigaction (int __sig, const struct sigaction *__restrict __act, struct sigaction *__restrict __oact)
```

* **__sig:** 和 signal 函数一样，传递信号；
* **__act:** 信号处理方式；
* **__oact:** 通过此参数获取之前注册的信号处理函数指针，如果不需要则传递 0；

---
大家其实看到第三个参数是一个结构体：
我们来解析以下它：

```
struct sigaction  
  {  
    union {  
   /* Used if SA_SIGINFO is not set.  */  
        __sighandler_t sa_handler;  
   /* Used if SA_SIGINFO is set.  */  
         void (*sa_sigaction) (int, siginfo_t *, void *);  
      } __sigaction_handler;

  
    /* Additional set of signals to be blocked.  */  
    __sigset_t sa_mask;  
  
    /* Special flags.  */  
    int sa_flags;  
  
    /* Restore handler.  */  
    void (*sa_restorer) (void);  
  };
```

---
* **__sighandler_t sa_handler：**  和原来的 signal 函数需要的处理函数很相似 基本一样；
* void (*sa_sigaction) (int, siginfo_t *, void *)： 当 sa_flags 成员值是否设置了 SA_SIGINFO 位时，系统将使用 sa_sigaction 函数作为信号处理函数，否则使用 sa_handler 作为信号处理函数；
* **sa_mask：** 用于指定在信号处理函数执行期间这个信号不会再度发生。
* **sa_flags：** 用于指定信号处理的方式，可以是值的“按位与”组合；
* **最后一个参数已经废弃；**

---
### 发送信号

---
##### kill

```
int kill (__pid_t __pid, int __sig)
```

* **__pid：** 标示一个或者多个目标进程；
* **__sig：** 指定了要发送的信号；
  如果 pid&gt;0：发送信号给指定的进程；
  如果 pid=0：会发送给调用进程同组的每一个进程，包括自己；
  如果 pid&lt;-1：那么向组 IP 等于 pid 绝对值的进程组内的所有下属进程发送信号；
  如果 pid=-1：调用进程所有权将信号发往每一个目标进程，除去（PID=1) 和调用进程本身；

---
##### raise

```
int raise (int __sig)
```

在单线程中，相当于，`kill(getpid(),sig);`
在多线程中，相当于， `pthread(pthread_self() , sig);`

##### killpg

```
int killpg (__pid_t __pgrp, int __sig)
```

相当于调用 `kill(-pgrp,sig);`
像某一进程组的所有成员发送一个信号；

---
### 显示信号描述

---
##### strsignal

```
#include <string.h>
char *strsignal (int __sig)
```

返回 sig 的相关描述信息；

---
也可以直接从 下面这个数组中获取

```
/* Names of the signals.  This variable exists only for compatibility.
   Use `strsignal' instead (see <string.h>).  */
extern const char *const _sys_siglist[_NSIG];
```

---
##### psignal

```
void psignal (int __sig, const char *__s);
```

---
### 信号集处理

许多信号相关的系统调用都需要能表示一组不同的信号的结构，多个信号可使用一个叫信号集的数据结构来表示，系统数据类型为  sigset_t;（比如：sigaction 函数和sigprocmask 函数用于程序指定一组不被进程接受的信号）

---
##### sigemptyset

初始化一个未包含所有的信号的信号集

```
int sigemptyset (sigset_t *__set)
```

---
##### sigfillset

初始化一个信号集，包含所有的信号；

```
int sigfillset (sigset_t *__set) 
```

---
##### sigaddset

给它一个信号集中添加单个元素

```
int sigaddset (sigset_t *__set, int __signo)
```

---
##### sigdelset

给一个信号集中移除一个元素

```
int sigdelset (sigset_t *__set, int __signo)
```

---
##### sigismember

测试信号是否是这个信号集的成员，如果是，返回 1，否则返回 0

```
int sigismember (const sigset_t *__set, int __signo)
```

---
### 信号掩码

内核会为每个进程维护一个信号掩码，即一组信号，用来阻塞其对进程的传递，也就是在这组信号中，该进程就无法收到该信号；如果把被阻塞的信号发送给某线程，那么该信号的传递将延后，直到它从掩码中移除，也就是接触阻塞位置，信号掩码是多线程进制的，在多线程中，每个线程都可以使用 pthread_sigmask（）函数来独立检查和修改其信号掩码；

##### sigprocmask

显式的向信号掩码中添加或移除信号

```
 int sigprocmask (int __how, const sigset_t *__restrict __set, sigset_t *__restrict __oset)
```

* **how 参数：**

|参数|介绍|
|---|---|
|SIG_BLOCK|将 set 指向的信号集内的信号添加到信号掩码中，也就是拿当前集合和 set 的并集|
|SIG_UNBLOCK|将 set 指向的信号集中的元素从信号掩码中移除，即使要解除阻塞的信号当前并未处于阻塞状态，也不会产生错误|
|SIG_SETMASK|将 set 指向的信号集赋给信号掩码|

-----------

### 处于等待状态的信号

-----
##### sigpending
如果某进程接受了一个该进程正在阻塞的信号，那么会将该信号添加到信号的等待集合中，当解除以后，就发送给进程；
```
int sigpending (sigset_t *__set)
```
-------------

### 等待信号
-----
##### pause
调用 pause 将暂停进程的执行，直到信号处理函数终端该调用为止或者直至一个未处理信号终止进程为止；
```
#include  <unistd.h>
int pause (void)
```
