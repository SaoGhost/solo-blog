title: TCPIP网络编程
date: '2019-10-06 18:44:11'
updated: '2019-10-09 13:22:43'
tags: [C, Linux, TCPIP网络编程]
permalink: /articles/2019/10/06/1570358651807.html
---
![09fa513d269759ee2f564e13b4fb43166c22dfe7.jpg](https://img.hacpai.com/file/2019/10/09fa513d269759ee2f564e13b4fb43166c22dfe7-82b8ba35.jpg)
[](https://)

# TCPIP 网络编程

---
## 网络编程

什么是网络编程，其实就是计算机之间互相交换数据；

那什么又是套接字呢，套接字（socket）是一个抽象层，应用程序可以通过它发送或接收数据，可对其进行像对文件一样的打开、读写和关闭等操作。套接字允许应用程序将 I/O 插入到网络中，并与网络中的其他应用程序进行通信。网络套接字是 IP 地址与端口的组合，socket 部件是由操作系统提供的；（我们先不考虑物理连接，我们默认所有的计算机都已经连接在巨大的互联网中）；

---
### TCP 协议和 UDP 协议

TCP 和 UDP 是传输层具有代表性的协议，TCP 提供可靠的通信传输，而 UDP 则常用于让广播和细节控制交给应用的通信传输；

TCP 通信的时候，客户端和服务器先要建立连接；
UDP 是无连接的，所以我们无需像 TCP 那样需要在连接上有很多的花销，有人会说，UDP 既然是不可靠的，那 TCP 肯定比 UDP 好吧！其实不然，在可靠性上，TCP 优于 UDP，但是 UDP 比 TCP 更简洁；

TCP 和 UDP 其实有一个很大的不同，就是 TCP 在不可靠的 IP 层进行流控制，而 UDP 就缺少这层控制;

我们在传输压缩文件的时候，比如发送 100 个数据，但是只要丢失一个数据包就会出问题，所以就必须使用 TCP，但是我们在网络实时传输视频或音频的时候，我们讲究的是实时性和速度，以及整体的流畅性，我们就可以用 UDP，就算我们在传输途中丢失了一部分，也仅仅只会引起轻微的画面卡顿，不会去影响整体（也不是所有的时候 UDP 都快于 TCP）；

为什么有些时候 TCP 会比 UDP 慢呢

* 收发数据前后 需要进行连接 和断开连接操作
* 收发数据过程中为保证可靠性而添加的流控制；

---
## TCP Sokcet 编程

---
### 通信流程

先看 TCP socket 通信的一个流程，这些具体的函数，我会在最后介绍；

**TCP 服务器：**

socket()(创建套接字) ——&gt; bind() (分配套接字地址)——&gt; listen()(等待连接请求状态)——&gt; accept()(允许连接)——&gt; read()/write() (数据交换)——&gt; close()(断开连接);

**TCP 客户度：**

socket() (创建套接字)——&gt;connect()（准备连接）——&gt;read()/write() （交换数据）——&gt;close() （断开连接）;

---
![TCP 网络编程.jpg](https://img.hacpai.com/file/2019/10/TCP%E7%BD%91%E7%BB%9C%E7%BC%96%E7%A8%8B-3aa70cfe.jpg)

---
### 代码实现

---
##### 服务器端

---
```
#include <stdio.h>

#include <sys/socket.h>

#include <netinet/in.h>

#include <string.h>

#include <unistd.h>

 

void print_error(char   string[]){

    printf("Usage: %s  Connect  Error\n",string);

};

 

int main() {

 
    int server_socket,client_socket;

    struct  sockaddr_in  server_addr;
    struct  sockaddr_in   client_addr;


    int port;

 
    printf("Please Entry Port\n");
    scanf("%d",&port);
    printf("接收的端口号是：%d\n",port);


    server_socket=socket(PF_INET,SOCK_STREAM,0);

    if (server_socket==-1){
        print_error("Socket");
    }

 

    memset(&server_addr,0, sizeof(server_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_addr.s_addr=htonl(INADDR_ANY);
    server_addr.sin_port=htons(port);


    if (bind(server_socket,(struct sockaddr *)&server_addr, sizeof(server_addr))==-1){
        print_error("Bind");
    }
 
    if (listen(server_socket,5)==-1){
        print_error("Listen");
    }

    socklen_t client_len= sizeof(client_addr);
    if ((client_socket=accept(server_socket,(struct sockaddr *)&client_addr,&client_len))==-1){
        print_error("accept");
    }

    char message[]="我是你爸爸";
    write(client_socket,message, sizeof(message));
    close(client_socket);
    close(server_socket);

    return 0;

}
```

---
##### 客户端

---
```
#include <stdio.h>

#include <sys/socket.h>

#include <netinet/in.h>

#include <string.h>

#include <unistd.h>

#include <arpa/inet.h>

void print_error(char   string[]){

    printf("Usage: %s  Connect  Error\n",string);

};

int main() {

 

    struct sockaddr_in server_addr;

    int sock;

    char addr[20];

    int port;

 

    printf("Please Entry Addr\n");

    scanf("%s",addr);

    printf("Please Entry %s\n",addr);

  

    printf("Please Entry Port\n");

    scanf("%d",&port);

    printf("Please Entry %d\n",port);

  

    if ((sock=socket(PF_INET,SOCK_STREAM,0))==-1){

        print_error("socket");

    }

 

    memset(&server_addr,0, sizeof(server_addr));

 

    server_addr.sin_family=AF_INET;

    server_addr.sin_addr.s_addr=inet_addr(addr);

    server_addr.sin_port=htons(port);

 

//    size_t server_addr_len = ;

    if (connect(sock,(struct sockaddr*)&server_addr,sizeof(server_addr))==-1){

        print_error("Connect");

    }

    char message[30];

    read(sock,message, sizeof(message));

 

    printf("%s\n",message);

    close(sock);

 

    return 0;

}
```

---
### 函数解析

导入 import &lt;sys/socket.h&gt;；

---
##### **1. Socket（）函数：**

使用 socket 函数创建套接字

```
 int socket (int __domain, int __type, int __protocol)
```

* _**domain：协议族（protocol family）:** 常用的有 AF_INET; AF_INET6;  AF_UNIX;  AF_ROUTE 等等（可以到 bit/socket.h 标准库中查看）；
* **_type:套接字类型（Type）** 常用的 socket 类型有： SOCK_STREAM（顺序，可靠的，面向连接的字节流，）、SOCK_DGRAM（无连接的，不可靠的数据报，固定最大长度，速度快）、SOCK_RAW（原始协议接口）、SOCK_PACKET、SOCK_SEQPACKET 等等（可以到 h 标准库下查看）
* **_protocol:选择的最终协议** 常用的协议有：IPPROTO_TCP（）、IPPTOTO_UDP、IPPROTO_SCTP、IPPROTO_TIPC 等等（在 netinet/in.h 标准库中可以查看）；如果该参数为 0，则让系统自动选择合适的协议，一般我们也这么操作，除非遇见“同一协议族中存在多个数据传输方式相同的协议；
* **返回值：** 成功返回文件描述符，失败返回-1

---
##### **2. bind（）函数：**

调用 bind 函数分配 IP 地址和端口号

```
int bind (int __fd, __CONST_SOCKADDR_ARG __addr, socklen_t __len)
```

* **_fd：** socket 文件描述符，就是 socket()的返回值；**
* **__CONST_SOCKADDR_ARG：** const struct sockaddr * 的 预定义；指向 sock 地址的指针；一般用 结构体 struct sockaddr_in 来代替 sockaddr；（可以到 bit/socket.h 标准库中查看）
* **socklen_t：** sock 地址的长度
* **返回值：** 成功为 0；失败返回-1

---
##### **3.  Listen（）函数：**

调用 listen 函数转为可接收请求状态

```
int listen (int __fd, int __n)
```

* **_fd:** 被监听的套接字；
* **_n：** 最大等待队列数量，宏 SOMAXCONN 为系统设定的最大值，可通过/etc/sysctl.conf 修改；
* **返回值：** 成功返回 0；失败返回-1；

---
##### **4.Accept（）函数：**

```
int accept (int __fd, __SOCKADDR_ARG __addr, socklen_t *__restrict __addr_len);
```

* **_fd:** 被监听的套接字；
* **SOCKADDR_ARG：** 返回客户端的地址，可为 NULL；
* **addr_len：** 客户端的地址长度，可以为 NULL；
* **返回值：** 成功为返回已连接的套接字的描述符 connfd，失败为-1；

---
##### **5.connect（） 函数：**

```
 int connect (int __fd, __CONST_SOCKADDR_ARG __addr, socklen_t __len
```

* **_fd:** 客户端的套接字描述符；
* **__addr:** 服务器的地址；
* **__len：** 服务器地址的长度；
* **返回值：** 成功返回 0，失败返回-1；

---
##### **注意：**

1. unistd.h 库是 unix std 的意思，是 POSIX 标准定义的 unix 类系统定义符号常量的头文件，包含了许多 UNIX 系统服务的函数原型，例如 read 函数、write 函数和 getpid 函数；
2. 实现服务端的必经过程之一就是给套接字分配 IP 和端口号（bind），但是大家发现没有，客户端直接 connect，，并没有去 bind，客户端难道就不需要绑定 Ip 端口吗，不是的，网络数据交换必须分配 Ip 和端口。那客户端何时，何地分配地址呢：在调用 connect 函数的时候；在操作系统的内核中，Ip 用的是计算机的 Ip，而端口是随机的；（也就是说客户端的 IP 地址和端口会在调用 connect 函数的时候自动分配）

---
## UDP Socket 编程

---
### 通信流程

---
![UDP 网络编程.jpg](https://img.hacpai.com/file/2019/10/UDP%E7%BD%91%E7%BB%9C%E7%BC%96%E7%A8%8B-dc008838.jpg)

---
### 代码实现：

其实 UDP 和 TCP 不同，不存在请求连接和受理过程，因此某种意义上讲，不区分客户端和服务器，但是因为他提供服务就称为服务器

---
##### 服务端：

```
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <zconf.h>


int main() {

    struct sockaddr_in server_addr,client_addr;

    int server_sock;

    if ((server_sock=socket(PF_INET,SOCK_DGRAM,0))==-1){
        printf("socket error");
    }

    char addr[20];
    int port;

    printf("Please Entry Port\n");
    scanf("%d",&port);
    printf("您接受的端口号是： %d\n",port);

    memset(&server_addr,0, sizeof(server_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(port);
    server_addr.sin_addr.s_addr=htonl(INADDR_ANY);

    if (bind(server_sock,(struct sockaddr *)&server_addr, sizeof(server_addr))==-1){
        printf("bind error");
    }

    char message[20];
    socklen_t  client_addr_len= sizeof(client_addr);
    recvfrom(server_sock,message, sizeof(message),0,(struct sockaddr*)&client_addr,&client_addr_len);

    printf("客户端来信：%s\n",message);
    char rec_message[]="已处理";


    printf("服务器回信：%s \n",rec_message);


    sendto(server_sock,rec_message, sizeof(rec_message),0,(struct sockaddr*)&client_addr,client_addr_len);
    close(server_sock);
    return 0;
}
```

---
##### 客户端：

```
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <zconf.h>

int main() {
    struct sockaddr_in server_addr;

    int server_sock;

    if ((server_sock=socket(PF_INET,SOCK_DGRAM,0))==-1){
        printf("socket error");
    }

    char addr[20];
    int port;

    printf("Please Entry Addr\n");
    scanf("%s",addr);
    printf("您请求的地址是： %s\n",addr);


    printf("Please Entry Port\n");
    scanf("%d",&port);
    printf("您请求的端口是： %d\n",port);


    memset(&server_addr,0, sizeof(server_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(port);
    server_addr.sin_addr.s_addr=inet_addr(addr);

    char message[]="国庆节快乐";
   sendto(server_sock,message, sizeof(message),0,(
    struct sockaddr *)&server_addr, sizeof(server_addr));

    socklen_t server_len= sizeof(server_addr);
    recvfrom(server_sock,message, sizeof(message),0,(struct sockaddr*)&server_addr,&server_len);

    printf("服务器通知：%s\n",message);

    close(server_sock);
    return 0;
}
```

---
### 函数解析：

---
##### **1. sendto()函数：**

```
ssize_t sendto (int __fd, const void *__buf, size_t __n,  int __flags, __CONST_SOCKADDR_ARG __addr, socklen_t __addr_len)
```

* **int __fd：** UDP 套接字文件描述符（文件句柄）；
* const void *__buf： 传输数据的缓冲地址；
* **size_t __n：** 待传输的数据长度；
* **int __flags：** 可选项参数，没有则传递 0；
* **__CONST_SOCKADDR_ARG __addr：** 存有目标地址信息 的 sockaddr 结构体变量的地址值；
* **socklen_t __addr_len：** 传递给目的地址的结构体的变量长度；

---
##### **2. recvfrom()函数：**

```
ssize_t recvfrom (int __fd, void *__restrict __buf, size_t __n, int __flags, __SOCKADDR_ARG __addr,  socklen_t *__restrict __addr_len)
```

* **int __fd：** UDP 套接字文件描述符（文件句柄）
* void *__restrict __buf： 接受数据的缓冲地址;
* **size_t __n：** 待接受的数据长度;
* **int __flags：** 可选项参数，没有则传递 0；
* **_SOCKADDR_ARG __addr：** 存有发送端信息 的 sockaddr 结构体变量的地址值；
* **socklen_t __restrict __addr_len：** 保存发送端地址的结构体的变量长度；

---
##### **注意：**

1. 在 TCP 客户端中，客户端的 IP 和端口是由 connect 函数来自动完成的，那么在上面的 UDP 代码中，大家发现没有并没有这个 conncet 函数。那么在何时分配 IP 和端口号么？在 UDP 中，在调用 sendto()函数之前，应该完成对套接字的地址分配工作，因此，要调用 bind() 函数，如果在调用 sockto() 函数时候，发现未分配地址，sendto() 函数会自动的给相应的套接字自动分配 IP 和端口（调用 bind() 函数），并持续到程序结束；
2. TCP 套接字中需要注册待传输数据的目标 IP 和端口号，而 UDP 中则无需注册，因此在通过 sendto 函数传输数据的过程可以分为下面三个阶段：

* **第一阶段：** 向 UDP 套接字注册目标 IP 和端口号；
* **第二阶段：** 传输数据；
* **第三阶段：** 删除 UDP 套接字中注册的地址信息；

·

3. 每次调用 sendto 函数重复上面的过程，这种未注册目标地址的套接字称为未连接套接字；但是我们的 UDP 程序在向同一个地址连续发送数据的时候，我们每次重复上面的过程反而降低了效率，所以我们先通过 connect 注册套接字，这样就提高了效率。虽然，看起来就和 TCP 一样了，但是我们的 sokcet 是 UDP 套接字，调用 conncet 并不会意味着和对方建立连接，只是注册 IP 和端口号而已，在成为 conncet 套接字以后，就还可以使用 write，和 read 函数进行通信了；

---
