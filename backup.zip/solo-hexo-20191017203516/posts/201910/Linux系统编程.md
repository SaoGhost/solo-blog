title: Linux 系统编程
date: '2019-10-14 20:30:29'
updated: '2019-10-16 12:34:58'
tags: [Linux]
permalink: /articles/2019/10/14/1571056229441.html
---
## Linux 系统编程

---
### 1.IO 模型

---
* ##### [文件IO](https://yanjj98.cn/articles/2019/10/15/1571102317255.html)
* ##### [文件描述符](https://yanjj98.cn/articles/2019/10/15/1571137506280.html)
* ##### [I/O复用](https://yanjj98.cn/articles/2019/10/16/1571199706018.html)


---
### 2.进程 和线程

* ##### [进程](https://yanjj98.cn/articles/2019/10/12/1570884903932.html)

---
### 3.内存管理

* ##### [内存分配有关函数解析](https://yanjj98.cn/articles/2019/10/12/1570884839661.html)

---
### 4.信号

* ##### [Linux ： 信号相关的函数](https://yanjj98.cn/articles/2019/10/12/1570884962271.html)

---
### 5.网络编程

* ##### [TCP/IP网络编程入门](https://yanjj98.cn/articles/2019/10/12/1570884623725.html)
* ##### [ 承载网络地址的结构体 和 地址序列](https://yanjj98.cn/articles/2019/10/12/1570884776650.html)

---
