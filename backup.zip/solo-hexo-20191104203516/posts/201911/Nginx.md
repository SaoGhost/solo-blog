title: 'Nginx '
date: '2019-11-01 21:08:45'
updated: '2019-11-02 10:05:08'
tags: [Nginx]
permalink: /articles/2019/11/01/1572613725664.html
---
![](https://img.hacpai.com/bing/20180827.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## Nginx

Nginx 是一个 Web 服务器，它采用的是 master/worker 进程池的机制，master 进程 负责监控 worker 进程，不处理具体的请求，而 worker 进程负责具体的请求，Nginx 在设计的时候就让它具有 CPU 的亲和性，可以通过配置让每个进程单独的运行在一个 CPU 核心上，较少 CPU 上下文调度的损耗；

-------
### Nginx 安装

##### 打包工具安装：
直接使用新提供的工具来安装，Debian系列使用 `apt` 工具，CentOs可以使用`yum`工具安装；
`apt/yum install  nginx`

##### 源码安装
保证你的系统里有`GCC`或者其他的C编译器，没有的可以根据自己的系统直接通过`apt`或者`yum`安装；
除了GCC，Nginx 还依赖下面的几个第三方库 `zlib`,`pcre`,`openssl`；我以Debian系统为例：
`sudo  apt install libz-dev`  (gzip压缩解压缩功能)
`sudo apt install pcre`  （正则表达式解析功能）
`sudo apt install openssl`  （SSL/TLS功能）

------
然后下载Nginx的源码压缩包，可以直接上官网去下,也可用用`wget`
`wget  http://nginx.org/download/nginx-1.16.0.tar.gz`

-----
解压缩：
`tar xvfz nginx-1.6.0.tar.gz`

----
进入解压后的目录：
`./configure` 
`make`
`make install`
默认就会安装在`/usr/local/nginx/`目录下；

---
然后 进入 `/usr/local/nginx/sbin/`目录下，执行 `./nginx -v`,会报出版本号，证明你安装成功了，我们为了省事，我们可以创建nginx 的软链接，在`/usr/local/nginx/sbin/`目录下`ln nginx  /usr/bin/nginx `,这样我们就不需要每次执行nginx 都要到sbin文件下了；

----
### 启动nginx

在终端运行`${postion}/nginx/sbin/nginx`,postion是你安装的nginx 的目录，默认在 `/usr/local/nginx`.如果制作了软链接，也可以直接`nginx`.
如果你是使用包管理工具安装的，那么直接`nginx`，就运行了。如果显示没有这条命令，就证明没有软链接，自己做一个就好（一般来说，是不可能没有的）；
打开浏览器，输入`127.0.0.1:80` ,如果出来`Welcome to  Nginx！`，就证明启动成功；

---------
### 目录结构

![image.png](https://img.hacpai.com/file/2019/11/image-38060659.png)

conf中是它的配置文件目录；
sbin中的nginx 是可执行文件；
logs是存放运行日志的目录；
html 存放的是默认的HTML文件；

--------
### Nginx 的简单命令
大家可以通过 `nginx -h`来查看全部的Nginx命令，下面介绍几个常用的命令：
`nginx -p  路径` 设置Nginx的工作路径；
`nginx -c 配置文件` 设置指定的配置文件启动Nginx；
`nginx -s quit`处理完当前所有的连接后停止服务；
`nginx -s stop`强制停止服务；
`nginx -s reload`重启服务，重新加载配置文件，但是服务不会中断；
`nginx -s reopen`重新打开日志文件，对服务无影响；

注意：如果在启动nginx 的时候使用了  `-p`，`-c` ，那么在使用`-s` 操作的时候必须也加上`-c`，`-p`参树，告诉Nginx使用的是那个配置文件；例如：`nginx -s reload -c xxx.conf`
