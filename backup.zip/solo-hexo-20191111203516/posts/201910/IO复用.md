title: I/O复用
date: '2019-10-18 20:51:37'
updated: '2019-10-30 16:48:09'
tags: [Linux]
permalink: /articles/2019/10/18/1571403097650.html
---
![](https://img.hacpai.com/bing/20191010.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

我们之前使用的大部分IO模型都是单个进程在单个文件描述符上执行IO操作，每次IO都会阻塞直到完成数据传输。但是仅仅阻塞IO是不能够满足我们的需求的；

## IO复用常用的三种模型


### select
----------
##### select 步骤解析
![select函数.jpg](https://img.hacpai.com/file/2019/10/select函数-cd77ca26.jpg)


------
##### select 参数解析
```
#include  <sys/select.h>
int select (int __nfds, fd_set *__restrict __readfds,
		   fd_set *__restrict __writefds,
		   fd_set *__restrict __exceptfds,
		   struct timeval *__restrict __timeout);
```
* **nfds：** 是指监视对象文件描述符的数量
* **readfds：** 将关注是否  存在待读取  的文件描述符,并注册到 fd_set变量中；
* **writefds：** 将关注  是否可传输无阻塞数据  的文件描述符,并注册到 fd_set变量中；
* **exceptfds：** 将关注  是否发生异常的  文件描述符,并注册到 fd_set变量中；
* **timeout：** 调用select 函数以后，为防止陷入无限阻塞当中，传递超时信息；
* **返回值：** 成功返回可用的文件描述符数量，错误返回-1；


------
上面的readfds 和 writefds 以及 exceptfds  它们是个结构体：这个结构体是存有0和1的位数组；
![fdset结构图.jpg](https://img.hacpai.com/file/2019/10/fdset结构图-df53cd03.jpg)
如图所示，很清楚的看到 fd2，和fd4 是我们的监视文件描述符；

-----------

``` C
typedef struct
  {
    /* XPG4.2 requires this member name.  Otherwise avoid the name
       from the global namespace.  */
#ifdef __USE_XOPEN
    __fd_mask fds_bits[__FD_SETSIZE / __NFDBITS];
# define __FDS_BITS(set) ((set)->fds_bits)
#else
    __fd_mask __fds_bits[__FD_SETSIZE / __NFDBITS];
# define __FDS_BITS(set) ((set)->__fds_bits)
#endif
  } fd_set;
```
这个结构体，我们只需要知道它是承载 我们要监管的描述符就够了；
有了这个结构体，我们当然需要给这个容器中添加描述符；
```
/* Access macros for `fd_set'.  */
#define	FD_SET(fd, fdsetp)	__FD_SET (fd, fdsetp)
#define	FD_CLR(fd, fdsetp)	__FD_CLR (fd, fdsetp)
#define	FD_ISSET(fd, fdsetp)	__FD_ISSET (fd, fdsetp)
#define	FD_ZERO(fdsetp)		__FD_ZERO (fdsetp)
```
我们对fd_set 中的文件描述符操作就可以通过上面的这些宏来完成：
* **FD_SET：** 将fd_set中的所有位设置为0；
* **FD_CLR：** 在fd_set中注册描述符fd；
* **FD_ISSET：** 若fd_set中存在 该描述符，就返回真；
* **FD_ZERO：** 清除fd_set中描述符的信息；

-----
下面这个是timeval的结构体：
```
struct timeval
  {
    __time_t tv_sec;		/* Seconds.  */
    __suseconds_t tv_usec;	/* Microseconds.  */
  };
```
select 函数，只有在监视的文件描述符发生变化后才返回，但是如果没有发生变化，就会进入阻塞状态；而这个结构体就可以设置超时时间；如果文件描述符未发生改变，只要过了指定时间，也可以从函数中返回；不过这种情况，select 函数返回0.当然，如果不想设置超时，传递NULL就可以了；

------
##### 简单的使用
```
#include <stdio.h>
#include <unistd.h>
#include <sys/select.h>

int main() {

    fd_set read_set;
    struct timeval timeout;
    
    while (1) {

        // 将 read_set 归 0；
        FD_ZERO(&read_set);
        // 将标准输入  放入 fd_set
        FD_SET(0, &read_set);

        // 如果没有在终端输入，五秒钟超时一次
        timeout.tv_sec = 5;
        
        int number = select(1, &read_set, NULL, NULL, &timeout);
        if (number == -1) {
            printf("select（） error");
            break;
        } else if (number == 0) {
            printf("NO  File Descriptor Prepared \n");
        } else {
            if (FD_ISSET(0, &read_set)) {
                char message[20];
                int len = read(0, message, sizeof(message));
                printf("收到终端输入信息：%s", message);
            }
        }
    }
    return 0;
}
```
###### 结果
```
NO  File Descriptor Prepared 
我输入了
收到终端输入信息：我输入了
NO  File Descriptor Prepared 
```
如果五秒钟没有收到终端输入，就会超时；如果 键盘输入字符串，select 就会监听到这一事件，执行读取终端字符串的操作；

--------
### poll
poll系统调用和select系统调用很相似，两者的主要区别就是select  ，提供了三个集合来表明我们关心的事件类型。而poll不一样，可以在一个文件描述符上表明多个我们关心的事件类型；

----
##### poll 参数解析
```
#include <poll.h>
int poll (struct pollfd *__fds, nfds_t __nfds, int __timeout);
```
* **__fds：**  这是一个结构体，每个结构体指定一个被监视的文件描述符；
* **__nfds：**  文件描述符数量
* **__timeout：** poll函数调用阻塞的时间，单位：毫秒；不论IO是否就绪，poll 调用都会返回；如果timeout为负数，表示永远等待；
timeout 为 0表示poll 调用立即返回，并给出 IO未就绪的文件描述符信息，不会等待更多时间；
* **返回值：** poll 调用成功，返回revents 变量不为0 的所有文件描述符个数；如果没有任何时间发生且未超时，返回 0；失败时，返回-1；并设置下面的errno值；

| 常量 |  说明 | 
| --- | --- | 
| EBADF | 一个或多个结构体中存在非法文件描述符 |  
| EFAULT | fds指针指向的地址超出了进程地址空间 |  
| EINTR | 在请求时间发生前收到了一个信号，可以重新发起调用 |
| EINVAL | nfds参数超过了 RLIMIT_NOFILE值 |
| ENOMEM | 可用内存不足，无法完成请求|

-------
```
/* Data structure describing a polling request.  */
struct pollfd
  {
    int fd;			/* File descriptor to poll.  */
    short int events;		/* Types of events poller cares about.  */
    short int revents;		/* Types of events that actually occurred.  */
  };

```
这个结构体中的fd 就是需要监控的文件描述符，events 就是 文件描述符关心的事件类型的位掩码；而revents  是该文件描述符 的结果事件的位掩码，内核返回时候会设置revents变量，events的所有事件都有可能在revents 中返回；

|位掩码| 说明|
| --- | --- |
| POLLIN  | 有数据可读 |
|POLLRDNORM | 有普通数据可读 |
|POLLRDBAND | 有优先级带数据可读 |
|POLLPRI | 有高优先级数据可读 |
|POLLOUT | 写操作不会阻塞 |
|POLLWRNORM | 写普通数据不会阻塞 |
|POLLWRBAND | 写优先数据不会阻塞 |
| POLLMSG | 有SIGPOLL消息可用 |
| 只有 revents 会返回的 |是下面三个|
|POLLERR | 发生错误 |
|POLLHUP | 发生挂起 |
|POLLNVAL | 给的文件描述符非法 |

看起来很复杂；其实  我们可以这么来看：
POLLIN| POLLPRL 就等价于 select 的读操作；
POLLOUT| POLLWRBAND 就等价于select的写操作；
而 异常操作，poll 是不需要显式的请求异常报告，而是会在 revents 变量中返回；

----------
POLLIN  等价于 POLLRDNORM | POLLRDBAND ；
POLLOUT 等价于 POLLWRNORM | POLLWRBAND;

------
##### poll的简单应用
```
#include <stdio.h>
#include <unistd.h>
#include <poll.h>

int main() {

    struct pollfd fds[2];

    fds[0].fd=0;
    fds[0].events=POLLIN;



    char message[20];

    int  result = poll(fds,1, 5000);
    if (result==-1){
        printf("error");
        return 1;
    } else if (result ==0){
        printf("TIMEOUT");
    }
if (fds[0].revents&POLLIN){
    read(0,message, sizeof(message));
    printf("就绪：%s\n",message);
}

    return 0;
}
```
###### 结果
```
我可以输入了
就绪：我可以输入了
```
------

###  Event poll 
poll 和 select ，每次调用的时候都需要一个被监视的文件描述符列表，内核必须遍历所有被监视的文件描述符；但是当超级多的文件描述符遍历的时候，每次调用就会成为一种规模上的瓶颈；
所有2.6内核之后，就加入了 event poll 机制；epoll 每次不需要遍历所有的文件描述符，而是只处理已就绪的文件描述符；

---
##### 创建epoll实例
```
#include <sys/epoll.h>
int epoll_create (int __size)
```
这个函数是老版本的，再见size 用于表示要监视的文件描述符个数；现在，内核可以动态的获取数据结构的大小，但是size 的值要大于0；如果小于0.会返回EINVAL；
```
#include <sys/epoll.h>
int epoll_create1 (int __flags)
```
调用成功，会创建新的epoll实例，并返回和该实例关联的文件描述符。这个文件描述符是为了后续调用epoll而创建的；参数 flags 支持修改epoll的行为；
目前只有一个有效参数： EPOLL_CLOEXEC  表示进程被替换时关闭文件描述符；
如果*flags*为0，则除了删除过时的*size*参数外，**epoll_create1**（）与**epoll_create**（）相同；

| 错误 | 描述 | 
| --- | --- | 
| EINVAL | 参数flags非法/在create 使用0 返回的意思是，size is not positive |  
| EMFILE  | 用户打开的文件数达到上限 |  
|  ENFILE |  系统打开的文件数达到上限|
|  ENOMEN | 内存不足，无法完成此次操作 |

----------------

##### 控制epoll
epoll_ctl 可以向指定的epoll上下文中加入或删除文件描述符；
```
#include <sys/epoll.h>
int epoll_ctl (int __epfd, int __op, int __fd, struct epoll_event *__event)
```
* **epfd：**  epoll实例文件描述符；
* **op：** 选项

| 参数 | 描述 | 
| --- | --- | 
| EPOLL_CTL_ADD | 把文件描述符 fd所指向的文件添加到epfd指定的epoll 监听实例集中，监听event中定义的事件  |  
| EPOLL_CTL_DEL | 把文件描述符fd所指向的文件从指定的epoll实例中删除 |  
| EPOLL_CTL_MOD |  使用event指定的更新时间修改在已有fd上的监听行为 |

* **fd ：**  文件描述符；
* **event：** 
```
struct epoll_event
{
  uint32_t events;	/* Epoll events */
  epoll_data_t data;	/* User data variable */
} __EPOLL_PACKED;

```
这个结构体中的 events 是 监听的事件，大概有以下选项：

| 事件 | 描述 | 
| --- | --- | 
|  EPOLLET  |  在监听文件上开启边缘触发  |  
|  EPOLLERR  |  文件出错，即使这个没有设置，这个事件也是被监听的 |  
|  EPOLLHUP | 文件被挂起，这个时间也是被监听的 |
|  EPOLLIN  |  文件未阻塞，可读|
|  EPOLLONESHOT | 在事件生成处理以后，文件不会被监听。必须通过EPOLL_CTL_MOD指定新的事件掩码，以便重新监听文件 |
|  EPOLLOUT |  文件未阻塞，可写 | 
|  EPOLLPRI | 存在高优先级的带外（out of band ）数据可读 |

event结构体中的data 也是一个结构体：
```
typedef union epoll_data  
{  
 void *ptr;  
 int fd;  
 uint32_t u32;  
 uint64_t u64;  
} epoll_data_t;
```
这个结构体是用户私有使用的，当接受到请求的事件后，data会返回给用户。通常会把event.data.fd 设置为fd，这样很容易查看 那个文件描述符 触发了事件；
* **返回值：**
成功时候，返回0；失败了，返回-1，并相应设置errno为下面的值；

| errno值 | 描述 |
| --- | --- | 
| EBADF  |  epfd不是有效的epoll实例，或者fd不是有效的文件描述符  |  
| EEXIST  |  op的值设置为EPOLL_CTL_ADD，但是，fd已经和epfd关联  |  
| EINVAL  |  epfd 不是epoll实例，epfd和fd相等，或者op无效 |
| ENOENT | op值设置为 EPOLL_CTL_MOD或者 EPOLL_CTL_DEL，但是 fd 没有和 epfd关联 |
|  ENOMEN | 没有足够的内存 |
|  EPERM | fd 不支持 epoll |

----

##### 等待epoll 事件
系统调用epoll_wait 会等待 和指定epoll 关联的文件描述符上的事件；
```
#include <sys/epoll.h>
int epoll_wait (int __epfd, struct epoll_event *__events,int __maxevents, int __timeout);
```
调用 epoll_wait 时，等待epoll 实例 epfd在中的文件fd 上的事件，时限为timeout毫秒，成功时，events指向描述 每个事件 的epoll_event结构体的内存，且最多有 maxevents 个事件，返回值是 事件数；当调用返回时，epoll_event结构体中的events 变量描述了发生的事件。data变量保留了用户在调用epoll_ctl之前的所有内容；出错 ，返回 -1 ，并将 errno 设置为 以下值；

| 值 | 描述 |
| --- | --- | 
| EBADF  |  epfd 是一个无效的文件描述符 |  
| EINVAL  |  epfd 不是有效的epoll实例，或者maxevents值小于或者等于0 |
| EFAULT |  进程对events 所指向的内存 没有 写权限 |
| EINTR |  系统调用完成前 发生信号中断或超时 |

如果timeout为0，即使没有事件发生，调用也会立即返回0.如果timeout为-1，调用将一直等待到有事件发生才返回；


-----

> ---学习至《TCPIP网络编程》 韩 尹圣雨著
> ---学习至 《Linux系统编程》
> ---学习至 《Linux/Unix系统编程手册》
